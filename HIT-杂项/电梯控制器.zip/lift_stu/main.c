��һ�壺�в��ִ���Ĵ���
module lift_stu(
    input clk,
    input [4:0] btn,
    output [4:0] nfloor,
    output [10:0] seg,
    output reg lift_open
    );
    parameter N=99_999999;
    reg [4:0] btn_pre_re,btn_buff,btn_off,btn_test;
    reg clk_200ms;
    reg clk_1s;
    reg clk_3s;
    reg [31:0] count,count1,count3;
    reg [10:0] dout;
    reg [1:0] lift_state;
    reg [2:0] lift_num;
    initial begin
        btn_off<=5'b11111;
        btn_pre<=0;
        lift_num<=3;
        lift_state<=0;
        lift_open<=1;
    end
     always@(posedge clk)begin
         clk_200ms<=0;
         if(count<N/5)
            count<=count+1;
         else begin
            count<=0;
            clk_200ms<=1;
        end
     end
      always@(posedge clk)begin
         clk_1s<=0;
         if(count1<N)
            count1<=count1+1;
         else begin
            count1<=0;
            clk_1s<=1;
        end
     end
      always@(posedge clk)begin
         clk_3s<=0;
         if(count3<(3*N-3))
            count3<=count3+1;
         else begin
            count3<=0;
            clk_3s<=1;
        end
     end
      always@(posedge clk_200ms)begin
          btn_pre_re=btn_pre_re^btn;
          btn_pre_re=btn_pre_re&btn_off;
     end
      always@(posedge clk_1s)begin
          btn_buff=btn_pre_re;
          case(lift_state)
              0:begin
                  if((btn_buff>>lift_num)>0)begin
                    #(5*N);
                    lift_num=lift_num+1;
                    lift_state=1;
                  end

                  if((btn_buff&(1<<(lift_num-1)))>0)begin
                    btn_buff=btn_buff&(~(1<<(lift_num-1)));
                    btn_off=~(1<<(lift_num-1));
                    lift_open=1;
                    #(5*N);
                    lift_open=0;
                    lift_state=0;
                  end

                  if((1<<(lift_num-1))>btn_buff)begin
                    if(btn_buff>0)begin
                      #(5*N);
                      lift_num=lift_num+1;
                      lift_state=2;
                    end
                  end
              end

              1:begin
                  if((btn_buff>>lift_num)>0)begin
                    if((btn_buff&(1<<(lift_num-1)))>0)begin
                        btn_buff=btn_buff&(~(1<<(lift_num-1)));
                        btn_off=~(1<<(lift_num-1));
                        lift_open=1;
                        #(5*N);
                        lift_open=0;
                        lift_num=lift_num+1;
                    end
                    else
                        lift_num=lift_num+1;
                  end
                  else begin
                        btn_buff=btn_buff&(~(1<<(lift_num-1)));
                        btn_off=~(1<<(lift_num-1));
                        lift_open=1;
                        #(5*N);
                        lift_open=0;
                        lift_state=0;
                  end
              end

              2:begin
                  btn_test=(btn_buff<<(6-lift_num));
                  if(btn_test>0)begin
                    if((btn_buff&(1<<(lift_num-1)))>0)begin
                        btn_buff=btn_buff&(~(1<<(lift_num-1)));
                        btn_off=~(1<<(lift_num-1));
                        lift_open=1;
                        #(5*N);
                        lift_open=0;
                        lift_num=lift_num-1;
                    end
                    else
                        lift_num=lift_num-1;
                  end
                  else begin
                        btn_buff=btn_buff&(~(1<<(lift_num-1)));
                        btn_off=~(1<<(lift_num-1));
                        lift_open=1;
                        #(5*N);
                        lift_open=0;
                        lift_state=0;
                  end
                end
            endcase
        end
        always@(posedge clk)begin
        case(lift_num)
            0:dout=11'b1110000_0001;
            1:dout=11'b1110_1001111;
            2:dout=11'b1110_0010010;
            3:dout=11'b1110_0000110;
            4:dout=11'b1110_1001100;
            5:dout=11'b1110_0100100;
            6:dout=11'b1110_0100000;
            7:dout=11'b1110_0001111;
            8:dout=11'b1110_0000000;
            9:dout=11'b1110_0000100;
            default:dout=11'b1110_0000001;
        endcase
    end
    assign nfloor=btn_pre_re;
    assign seg=dout;
endmodule















�ڶ��壺ʵ��6���ܵĴ��루�в������е�bug��
`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company:
// Engineer:
//
// Create Date: 2017/06/20 20:52:37
// Design Name:
// Module Name: lift_stu
// Project Name:
// Target Devices:
// Tool Versions:
// Description:
//
// Dependencies:
//
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
//
//////////////////////////////////////////////////////////////////////////////////


module lift_stu(
    input clk,
    input [9:0] btn,
    input btn1,
    output [9:0] nfloor,
    output [10:0] seg,
    output [10:0] seg1,
    output reg lift_open
    );
    parameter N=99_999999;
    reg [9:0] btn_pre_re,btn_buff,btn_off,btn_test;
    reg btn1_pre_re,btn1_off;
    reg clk_200ms;
    reg clk_1s;
    reg clk_3s;
    reg [31:0] count,count1,count3;
    reg [1:0] cou1,cou2,cou3,cou4,cou5,cou6,cou7;
    reg [10:0] dout,dout1;
    reg [1:0] lift_state;
    reg [4:0] lift_num,clk_num;
    initial begin
        btn_off<=9'b111111111;
        btn1_off<=1'b1;
        btn_pre_re<=0;
        lift_num<=3;
        lift_state<=0;
        lift_open<=1;
    end
     always@(posedge clk)begin   //��Ƶһ��200ms��ʱ�ӣ����ڰ�������
         clk_200ms<=0;
         if(count<N/5)
            count<=count+1;
         else begin
            count<=0;
            clk_200ms<=1;
        end
     end
      always@(posedge clk)begin   //��Ƶһ��1s��ʱ�ӣ����ڵ�������ʱ�ӿ���
         clk_1s<=0;
         if(count1<N)
            count1<=count1+1;
         else begin
            count1<=0;
            clk_1s<=1;
        end
     end
      always@(posedge clk_200ms)begin
          btn_pre_re=btn_pre_re^btn;
          btn_pre_re=btn_pre_re&btn_off;//������ƣ���������ڰ����ΰ���ʱ����ȡ���Ĳ���
          btn1_pre_re=btn1_pre_re^btn1;//��λ����
          btn1_pre_re=btn1_pre_re&btn1_off;
          if(btn1_pre_re==1)
          begin
          btn_pre_re<=9'b000000001;
          btn1_pre_re=0;
          end
     end
      always@(posedge clk_1s)begin
          btn_buff=btn_pre_re;//btn_pre_re�Ĵ水����Ϣ
          case(lift_state)
              0:begin
                  if((btn_buff>>lift_num)>0)begin
                  if(cou1<3)//����û�еķ���������C���Ե�˼�룬ʵ��3s����ʱ�����������ƴ���
                    begin
                    cou1=cou1+1;
                  end
                  if(cou1==3)
                    begin
                    lift_num=lift_num+1;
                    clk_num=clk_num+1;
                    lift_state=1;//�ϲ����˽е���
                  cou1=0;
                  end
                  end

                  if((btn_buff&(1<<(lift_num-1)))>0)begin
                    btn_buff=btn_buff&(~(1<<(lift_num-1)));//�������˽е���
                    btn_off=~(1<<(lift_num-1));
                    lift_open=1;
                    if(cou2<3)
                    begin
                    cou2=cou2+1;
                  end
                  if(cou2==3)
                    begin
                    clk_num=0;
                    lift_open=0;
                    lift_state=0;
                    cou2=0;
                    end
                  end

                  if((1<<(lift_num-1))>btn_buff)begin//�²����˽е���
                    if(btn_buff>0)begin
                      if(cou3<3)
                    begin
                    cou3=cou3+1;
                  end
                  if(cou3==3)
                    begin
                      lift_num=lift_num-1;
                      clk_num=clk_num+1;
                      lift_state=2;
                      cou3=0;
                      end
                    end
                  end
              end

              1:begin
                  if((btn_buff>>lift_num)>0)begin
                    if((btn_buff&(1<<(lift_num-1)))>0)begin
                        btn_buff=btn_buff&(~(1<<(lift_num-1)));
                        btn_off=~(1<<(lift_num-1));
                        lift_open=1;
                        if(cou4<3)
                    begin
                    cou4=cou4+1;
                  end
                  if(cou4==3)
                    begin
                        clk_num=0;
                        lift_open=0;
                        lift_num=lift_num+1;
                        clk_num=clk_num+1;
                        cou4=0;
                        end
                    end
                    else
                        lift_num=lift_num+1;
                        clk_num=clk_num+1;
                  end
                  else begin
                        btn_buff=btn_buff&(~(1<<(lift_num-1)));
                        btn_off=~(1<<(lift_num-1));
                        lift_open=1;
                        if(cou5<3)
                    begin
                    cou5=cou5+1;
                  end
                  if(cou5==3)
                    begin
                        clk_num=0;
                        lift_open=0;
                        lift_state=0;
                        cou5=0;
                        end
                  end
              end

              2:begin
                  btn_test=(btn_buff<<(9-lift_num));//�����¥���������һ��
                  if(btn_test>0)begin
                    if((btn_buff&(1<<(lift_num-1)))>0)begin
                        btn_buff=btn_buff&(~(1<<(lift_num-1)));
                        btn_off=~(1<<(lift_num-1));
                        lift_open=1;
                        if(cou6<3)
                    begin
                    cou6=cou6+1;
                  end
                  if(cou6==3)
                    begin
                        clk_num=0;
                        lift_open=0;
                        lift_num=lift_num-1;
                        clk_num=clk_num+1;
                        cou6=0;
                        end
                    end
                    else
                        lift_num=lift_num-1;
                        clk_num=clk_num+1;
                  end
                  else begin
                        btn_buff=btn_buff&(~(1<<(lift_num-1)));
                        btn_off=~(1<<(lift_num-1));
                        lift_open=1;
                        if(cou7<3)
                    begin
                    cou7=cou7+1;
                  end
                  if(cou7==3)
                    begin
                        clk_num=0;
                        lift_open=0;
                        lift_state=0;
                        cou7=0;
                        end
                  end
                end
            endcase
        end
        always@(posedge clk)begin
        case(lift_num)                //��¼��ǰ¥����������ʾ��·
            0:dout=11'b0100_1111110;
            1:dout=11'b0100_0110000;
            2:dout=11'b0100_1101101;
            3:dout=11'b0100_1111001;
            4:dout=11'b0100_0110011;
            5:dout=11'b0100_1011011;
            6:dout=11'b0100_1011111;
            7:dout=11'b0100_1110000;
            8:dout=11'b0100_1111111;
            9:dout=11'b0100_1111011;
            default:dout=11'b0100_1111110;
        endcase
    end
    always@(posedge clk)begin            //��¼��ͣʱ���ʱ�ӵ��������ʾ��·
            case(clk_num)
                0:dout1=11'b0100_1111110;
                1:dout1=11'b0100_0110000;
                2:dout1=11'b0100_1101101;
                3:dout1=11'b0100_1111001;
                4:dout1=11'b0100_0110011;
                5:dout1=11'b0100_1011011;
                6:dout1=11'b0100_1011111;
                7:dout1=11'b0100_1110000;
                8:dout1=11'b0100_1111111;
                9:dout1=11'b0100_1111011;
                default:dout1=11'b0100_1111110;
            endcase
            end
    assign nfloor=btn_pre_re;
    assign seg=dout;
    assign seg1=dout1;
endmodule
